//Aja Curry
//Stefanos Savvides

public class Location {

    String name;
    String description;

    Person[] people = new Person[5];
    Item[] items = new Item[5];
    String[] thingsToHunt;

}