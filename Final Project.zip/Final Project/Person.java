public class Person {
    
    String name;

    String description;

    public Person (){};

    public Person(String n, String d){
        name = n;
        description = d;
    }

    





}