//Aja Curry
//Stefanos Savvides

public class Item {
    
    String name;
    String description;


    public Item (){};
    
    public Item(String n, String d){
        name = n;
        description = d;
    }

    public String getDesc() {
        return description;
}
}
